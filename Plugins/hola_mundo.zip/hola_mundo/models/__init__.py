# hello_world/models/__init__.py
from . import hello_model
